export interface Project {
  slug: string;
  title: string;
  summary: string;
  description: string;
  year?: string;
  client?: string;
  tech: string[];
  images: string[];
  live?: string;
  repo?: string;
  featured?: boolean;
  award?: string;
  internal?: boolean;
}

/** /projects/<slug>/1.jpg … n.jpg */
const shots = (slug: string, count: number, ext = 'jpg') =>
  Array.from({ length: count }, (_, i) => `/projects/${slug}/${i + 1}.${ext}`);

// Order is deliberate: featured cards take 2 columns; this order fills the grid gap-free.
export const projects: Project[] = [
  {
    slug: 'mawkish-creates',
    title: 'Mawkish Creates',
    summary: 'Immersive 3D website for a creative agency.',
    description:
      'The official website for Mawkish Creates, a creative agency offering a range of design and production services. Built with an immersive 3D interface using Three.js and React Three Fiber, with Firebase for data and Node.js handling backend logic.',
    year: '2026',
    tech: ['Three.js', 'React Three Fiber', 'Node.js', 'Firebase'],
    images: shots('mawkish-creates', 5),
    live: 'https://mawkishcreates.com/',
    featured: true,
  },
  {
    slug: 'mawkish-erp',
    title: 'Mawkish Creates ERP',
    summary: 'Internal ERP for people, projects and performance.',
    description:
      'An internal ERP system built to manage staff relationships, track project progress, and maintain a results-driven, performance-monitored work environment.',
    year: '2026',
    tech: ['React', 'Node.js', 'Firebase'],
    images: shots('mawkish-erp', 5),
    internal: true,
    // The link you shared is a private Vercel dashboard (visitors would hit a login), so it's omitted.
  },
  {
    slug: 'physioconnect',
    title: 'PhysioConnect',
    summary: 'Real-time physiotherapy app built around a 2D body model.',
    description:
      'A real-time physiotherapy application centred on an interactive 2D body model, with pain monitoring, progress tracking and a nearby-facility locator. AR features are planned as a future enhancement.',
    year: '2024',
    tech: ['Flutter', 'Node.js', 'Express.js', 'MySQL'],
    images: shots('physioconnect', 5),
  },
  {
    slug: 'mawkish-technologies',
    title: 'Mawkish Technologies',
    summary: 'Corporate site for a business transformation partner.',
    description:
      'The official website for Mawkish Technologies, a business transformation partner helping organisations achieve measurable outcomes through SAP, Salesforce, Odoo and other enterprise technologies.',
    year: '2026',
    tech: ['React', 'Node.js', 'Firebase'],
    images: shots('mawkish-technologies', 5),
    live: 'https://mawkish-tecnologies.vercel.app/', // check spelling: "tecnologies"
    featured: true,
  },
  {
    slug: 'tariff-calculator',
    title: 'Real-Time Tariff Calculator',
    summary: 'Global tariff analysis for international trade.',
    description:
      'A real-time tariff analysis platform developed for MAS Intimates to compare products against global tariff rates and calculate export and import costs across international branches. The system provided global trade insights and supported data-driven pricing and strategic decisions.',
    year: '2025',
    client: 'MAS Intimates',
    tech: ['C#', '.NET', 'ASP.NET', 'Microsoft Azure', 'JavaScript'],
    images: shots('tariff-calculator', 1),
    internal: true,
    featured: true,
  },
  {
    slug: 'raciit-blog',
    title: 'RACIIT Blog',
    summary: 'Blog platform for RACIIT.',
    description: 'The blog platform for RACIIT, publishing club stories and updates.', // TODO: expand
    tech: [], // TODO
    images: shots('raciit-blog', 5),
    live: 'https://blog.raciit.info/',
  },
  {
    slug: 'raciit-annual-report',
    title: 'RACIIT Annual Report',
    summary: 'Web-based annual report for the 2025–26 term.',
    description: "A web-based annual report presenting RACIIT's 2025–26 term.", // TODO: expand
    year: '2025–26',
    tech: [], // TODO
    images: shots('raciit-annual-report', 5),
  },
  {
    slug: 'raciit-main',
    title: 'RACIIT Website',
    summary: 'Award-winning official website for RACIIT.',
    description: 'The official website of RACIIT, recognised with a Bronze award at the Rotaract District Assembly.', // TODO: expand
    year: '2025–26',
    tech: [], // TODO
    images: shots('raciit-main', 5),
    live: 'https://www.raciit.info/',
    award: 'Bronze · Rotaract District Assembly',
    featured: true,
  },
];
