import type { ReactNode } from 'react';

export function SectionHeading({
  index,
  label,
  title,
  kicker,
}: {
  index: string;
  label: string;
  title: ReactNode;
  kicker?: ReactNode;
}) {
  return (
    <div>
      <p className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.3em] text-neutral-500">
        <span aria-hidden className="h-px w-8 bg-red-700" />
        {index} / {label}
      </p>
      <h2 className="mt-5 max-w-4xl text-4xl font-black leading-[0.98] tracking-tight text-white md:text-6xl">
        {title}
      </h2>
      {kicker && <p className="mt-5 max-w-2xl text-neutral-400">{kicker}</p>}
    </div>
  );
}
