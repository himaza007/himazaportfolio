'use client';

import Image from 'next/image';
import { AnimatePresence, motion } from 'framer-motion';
import { useState, type ReactNode } from 'react';
import { about, type Experience } from '@/content/about';
import { Reveal } from '@/components/ui/Reveal';
import { SectionHeading } from '@/components/ui/SectionHeading';

const EASE = [0.22, 1, 0.36, 1] as const;
const PANEL = 'rounded-2xl border border-white/10 bg-black/45 backdrop-blur-2xl';

function PanelLabel({ children }: { children: ReactNode }) {
  return (
    <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-neutral-500">
      <span className="text-red-700">●</span> {children}
    </p>
  );
}

function Bullet({ children }: { children: ReactNode }) {
  return (
    <li className="flex gap-2.5">
      <span aria-hidden className="mt-[10px] h-px w-2.5 shrink-0 bg-red-700" />
      <span>{children}</span>
    </li>
  );
}

function Portrait() {
  const [failed, setFailed] = useState(false);

  return (
    <div className={`${PANEL} group relative aspect-[4/5] overflow-hidden`}>
      {failed ? (
        <div className="absolute inset-0 flex items-center justify-center text-7xl font-black text-white/10">
          HZ
        </div>
      ) : (
        <Image
          src={about.portrait}
          alt={`Portrait of ${about.name}`}
          fill
          sizes="(min-width: 1024px) 380px, 100vw"
          onError={() => setFailed(true)}
          className="object-cover grayscale transition duration-700 group-hover:scale-[1.03] group-hover:grayscale-0"
        />
      )}
      <div aria-hidden className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-60 mix-blend-soft-light transition-opacity duration-700 group-hover:opacity-0"
        style={{ background: 'radial-gradient(circle at 70% 20%, rgba(139,0,0,0.7), transparent 60%)' }}
      />
      <div className="absolute inset-x-0 bottom-0 flex items-center gap-2 p-5 font-mono text-[10px] uppercase tracking-[0.2em] text-neutral-300">
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-600 shadow-[0_0_8px_rgba(220,38,38,0.9)]" />
        {about.name}
      </div>
    </div>
  );
}

function ExperienceItem({ item }: { item: Experience }) {
  const [open, setOpen] = useState(false);
  const shown = item.highlights.slice(0, 2);
  const extra = item.highlights.slice(2);

  return (
    <li className="relative">
      <span
        aria-hidden
        className={`absolute -left-[29px] top-2 h-2.5 w-2.5 rounded-full border ${
          item.current
            ? 'border-red-600 bg-red-600 shadow-[0_0_10px_rgba(220,38,38,0.9)]'
            : 'border-white/30 bg-[#070707]'
        }`}
      />
      <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <h4 className="text-base font-semibold text-white md:text-lg">{item.role}</h4>
        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-neutral-500">{item.period}</span>
      </div>
      <p className="mt-0.5 text-sm text-red-400/80">
        {item.org}
        {item.type && <span className="text-neutral-500"> · {item.type}</span>}
      </p>

      {shown.length > 0 && (
        <ul className="mt-3 space-y-1.5 text-sm leading-relaxed text-neutral-400">
          {shown.map((h) => (
            <Bullet key={h}>{h}</Bullet>
          ))}
        </ul>
      )}

      <AnimatePresence initial={false}>
        {open && (
          <motion.ul
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.4, ease: EASE }}
            className="overflow-hidden text-sm leading-relaxed text-neutral-400"
          >
            {extra.map((h) => (
              <div key={h} className="pt-1.5">
                <Bullet>{h}</Bullet>
              </div>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>

      {extra.length > 0 && (
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          className="mt-2 font-mono text-[10px] uppercase tracking-[0.2em] text-neutral-500 transition-colors hover:text-red-400"
        >
          {open ? '− Show less' : `+ ${extra.length} more`}
        </button>
      )}
    </li>
  );
}

export function About() {
  return (
    <section id="about" data-section="about" className="relative px-4 pb-32 pt-40 md:px-8">
      <div className="mx-auto max-w-6xl">
        {/* GSAP (WarpScroll) reveals this block as the warp lands */}
        <div data-about-reveal>
          <SectionHeading index="02" label="About" title={about.intro} />
        </div>

        {/* Portrait + bio */}
        <div className="mt-16 grid gap-5 lg:grid-cols-12">
          <Reveal className="lg:col-span-4">
            <Portrait />
          </Reveal>

          <Reveal delay={0.1} className="lg:col-span-8">
            <div className={`${PANEL} flex h-full flex-col p-6 md:p-10`}>
              <PanelLabel>Profile</PanelLabel>
              <div className="mt-6 space-y-5 text-[15px] leading-relaxed text-neutral-300 md:text-base">
                {about.bio.map((p) => (
                  <p key={p.slice(0, 32)}>{p}</p>
                ))}
              </div>
              <dl className="mt-auto grid gap-5 border-t border-white/10 pt-6 sm:grid-cols-2">
                {[
                  { k: 'Currently', v: about.currently },
                  { k: 'Based in', v: about.location },
                ].map(({ k, v }) => (
                  <div key={k} className="pt-2">
                    <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-neutral-500">{k}</dt>
                    <dd className="mt-1.5 text-sm text-white">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </Reveal>
        </div>

        {/* Skills */}
        <Reveal className="mt-5">
          <div className={`${PANEL} p-6 md:p-10`}>
            <PanelLabel>Stack & capabilities</PanelLabel>
            <div className="mt-6 grid gap-8 sm:grid-cols-2 lg:grid-cols-5">
              {about.skills.map((g) => (
                <div key={g.group}>
                  <h3 className="text-sm font-semibold text-white">{g.group}</h3>
                  <ul className="mt-3 flex flex-wrap gap-1.5">
                    {g.items.map((s) => (
                      <li
                        key={s}
                        className="rounded-full border border-white/10 bg-white/[0.03] px-2.5 py-1 font-mono text-[10px] text-neutral-300 transition-colors duration-300 hover:border-red-800/50 hover:text-white"
                      >
                        {s}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* Experience + Education/Awards */}
        <div className="mt-5 grid gap-5 lg:grid-cols-12">
          <Reveal className="lg:col-span-7">
            <div className={`${PANEL} h-full p-6 md:p-10`}>
              <PanelLabel>Experience</PanelLabel>
              <ol className="relative mt-8 space-y-9 border-l border-white/10 pl-6">
                {about.experience.map((e) => (
                  <ExperienceItem key={`${e.role}-${e.org}`} item={e} />
                ))}
              </ol>
            </div>
          </Reveal>

          <div className="flex flex-col gap-5 lg:col-span-5">
            <Reveal delay={0.1}>
              <div className={`${PANEL} p-6 md:p-8`}>
                <PanelLabel>Education</PanelLabel>
                <ul className="mt-6 space-y-5">
                  {about.education.map((e) => (
                    <li key={e.title}>
                      <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-red-400/80">{e.status}</p>
                      <h4 className="mt-1 font-semibold text-white">{e.title}</h4>
                      <p className="text-sm text-neutral-400">{e.org}</p>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>

            <Reveal delay={0.18} className="flex-1">
              <div className={`${PANEL} h-full p-6 md:p-8`}>
                <PanelLabel>Recognition</PanelLabel>
                <ol className="mt-6 space-y-5">
                  {about.awards.map((a, i) => (
                    <li key={a.title} className="flex gap-4">
                      <span className="font-mono text-[10px] text-red-600">{String(i + 1).padStart(2, '0')}</span>
                      <div>
                        <h4 className="text-sm font-semibold leading-snug text-white">{a.title}</h4>
                        <p className="mt-0.5 text-sm text-neutral-400">{a.org}</p>
                      </div>
                    </li>
                  ))}
                </ol>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
